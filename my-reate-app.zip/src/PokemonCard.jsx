import { getTypeIconSrc } from './utils';

export default function PokemonCard({ pokemon }) {
    const {paddedId, name, types, imgSrc} = pokemon;

    return (
        <div className={`pokemon-card ${types[0].name}`}>
            <div>
                <span className="id-number">{`#${paddedId}`}</span>
                <span className="pokemon-name">{name}</span>

                <div className="types">                    
                    {types.map((type) => (
                        <div key={type.name} className={type.name}>
                            <img src={getTypeIconSrc(type.name)} alt={type.name} />
                            <span>{type.name}</span>
                        </div>
                    ))}                
                </div>
            </div>

            <img src={imgSrc} alt={name} className="pokemon-image" />
        </div>
    );
}